class View {
  constructor(game, $el) {
    this.game = game;
    this.$el = $el;

    this.setupBoard();
  }

  bindEvents() {
    let $li = $('<li>');

    $li.click( (event) => {
      let $square = $(event.currentTarget);
      this.makeMove($square);
    })
    
  };

  makeMove($square) {
    let pos = $square.data("pos");
    let currentPlayer = this.game.currentPlayer;

    this.game.makeMove(pos);
    $square.addClass(currentPlayer);

  }

  setupBoard() {
    let $ul = $("<ul>");

    for (let i = 0; i < 3; i++) {
      for (let j = 0; j < 3; j++) {
        let $li = $("<li>");
        $li.data("pos", [i, j]);

        $ul.append($li);
      }
    }

    this.$el.append($ul);
  }
}

module.exports = View;
